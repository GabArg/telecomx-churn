# Datos

Colocá acá los archivos necesarios (por ejemplo, `datos_tratados.csv`).  
**Importante:** esta carpeta está ignorada por git (.gitignore) para evitar subir datos sensibles o pesados.
